diary results257;
diary on;
%Problema 6
syms f(x) x;
f(x)=sqrt(5-3*x*x);
disp('Problema 6');
pretty(int(f(x),x));
%Problema 7
f(x)=sqrt(3-2*x-x*x);
disp('Problema 7');
pretty(int(f(x),x));
%Problema 8
f(x)=sqrt(5-2*x+x*x);
disp('Problema 8');
pretty(int(f(x),x));
%Problema 9
f(x)=sqrt(2*x-x*x);
disp('Problema 9');
pretty(int(f(x),x));
%Problema 10
f(x)=sqrt(10-4*x+4*x*x);
disp('Problema 10');
pretty(int(f(x),x));
%Problema 11
f(x)=sqrt(16-9*x*x);
disp('Problema 11');
pretty(int(f(x),x));
%Problema 12
f(x)=sqrt(4+25*x*x);
disp('Problema 12');
pretty(int(f(x),x));
%Problema 13
f(x)=sqrt(9*x*x-1);
disp('Problema 13');
pretty(int(f(x),x));
%Problema 14
f(x)=sqrt(8-3*x*x);
disp('Problema 14');
pretty(int(f(x),x));
%Problema 15
f(x)=sqrt(5+2*x*x);
disp('Problema 15');
pretty(int(f(x),x));
%Problema 16
f(x)=sqrt(5-4*x-x*x);
disp('Problema 16');
pretty(int(f(x),x));
%Problema 17
f(x)=sqrt(5+2*x+x*x);
disp('Problema 17');
pretty(int(f(x),x));
%Problema 18
f(x)=sqrt(x*x-8*x+7);
disp('Problema 18');
pretty(int(f(x),x));
%Problema 19
f(x)=sqrt(4-2*x-x*x);
disp('Problema 19');
pretty(int(f(x),x));
%Problema 20
f(x)=sqrt(x*x-2*x+8);
disp('Problema 20');
pretty(int(f(x),x));
diary off;
